# #format
# nome = input("Digite seu nome:\n ")
# idade = input("Digite aqui sua idade:\n ")
# meu_endereco = input("Digite seu endereço:\n ")
# cargo = input('Digite o seu cargo:\n')

# # print('Meu nome é ',nome , 'minha idade é ',idade, 'meu endereço',meu_endereco, 'meu cargo é',cargo,)

# print(f'Meu nome é {nome} minha idade é {idade} meu endereço {meu_endereco} meu cargo é {cargo}')


# # #5 -Declare uma variável contendo uma frase. Em seguida, peça ao usuário para digitar uma palavra e concatene essa palavra no final da frase. Exiba o resultado.
# f1 = input("Complete a frase: Só sei que nada_____\n")
# print(f'Frase completa: Só sei que nada {f1}')

# # 6 - Crie três variáveis para armazenar a quantidade de horas, minutos e segundos. Concatene esses valores para formar uma mensagem de tempo no formato "hh:mm:ss".**
# print('Crie um horario,contendo hora, minuto e segundo.\n') 
# h = input('Escolha uma hora contendo 2 dígitos:')
# m = input('Escolha o minutocontendo 2 dígitos:')
# s = input('Escolha o segundo contendo 2 dígitos:')

# print(f'Horario é: {h}:{m}:{s}')

# 7 -Declare duas variáveis com números de telefone, incluindo um código de área e o número principal. Concatene esses valores para formar um número de telefone completo.

# codigo = input("Digite o código de área(__)\n")
# phone = input('Digite seu telefone\n')
# print(f'Telefone:({codigo}){phone}')

# **8 Crie uma lista de ingredientes para uma receita. Use concatenação para formar uma única string que liste os ingredientes separados por vírgulas.**

# print("Crie uma receita de omelete, utilizando 4 ingredientes:")
# i1 = input("Item 1\n")
# i2 = input("Item 2\n")
# i3 = input("Item 3\n")
# i4 = input("Item 1\n")

# print(f'Sua receita é:{i1},{i2},{i3} e {i4}')

# 9 -Peça ao usuário para digitar três adjetivos e armazene-os em variáveis. Em seguida, use essas palavras para criar uma frase concatenada que descreve algo interessante.
# nome = input("Digite seu nome: \n")
# print("Cite três adjetivos sobre você.")








# a1 = input("1º")
# a2 = input("2º")
# a3 = input("3º")

# print(f'* {nome} é {a1},{a2},{a3}. Agora seja!!! kkkkk').


#condicionais







# numero = float(input("Digite um número"))

# if numero  == 10:
#   print(f'O número {numero}')
# else:
#   print(f' o número é {numero}')

# senha_digitada = input("Digite uma senha:\n")
# nome = input("Digite seu nome\n")
# senha = '1234'

# if senha  == senha_digitada and nome == 'Camila':
#   print("Acesse, vc digitou corretamente")
# else:
#  print(f'Não pode acessar, porque vc digitou {senha_digitada} ou {nome} inválido ')  

# **1 - Crie uma condição para comparar idades: 45 e 18 -  QUAL É MENOR E QUAL É MAIOR?**

# id1 = 45
# id2 = 18

# print(f'{id1} é > {id2}, {id2} é < {id1}')

# **2 - Crie um sistema para permitir a verificação de menores em um show**

# idade = int(input("Digite sua idade -\n"))

# if idade >= 18:
#   print("Acesso permitido")  
# else:
#   print("Acesso negado")


# **3 - Crie um algoritmo que permita a entrada de 3 notas de alunos, utilize o bloco de código if()**
 # **para verificar se o aluno passou.**

# print('Verifique sua aprovação')
# nota1 = float(input("Digite 1º nota - \n"))
# nota2 = float(input("Digite 2º nota - \n"))
# nota3 = float(input("Digite 3º nota - \n"))

# notas = nota1 + nota2 + nota3
# media = notas/3

# if media >= 5: 
#   print(f'{media} Aprovado!')
# else:
#   print(f'{media} #REPROVADO!!!')
  